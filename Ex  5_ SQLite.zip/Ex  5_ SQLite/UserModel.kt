package com.example.sqlite

class UserModel (val registernumber : String, val name : String, val cgpa :
String)